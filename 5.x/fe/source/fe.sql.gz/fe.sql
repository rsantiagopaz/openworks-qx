-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 11-02-2017 a las 21:14:58
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `fe`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fe_documento`
--

CREATE TABLE IF NOT EXISTS `fe_documento` (
  `id_fe_documento` int(11) NOT NULL AUTO_INCREMENT,
  `punto_vta` smallint(6) DEFAULT NULL,
  `tipo_cbte` tinyint(4) DEFAULT NULL,
  `cbt_desde` int(11) DEFAULT NULL,
  `cbt_hasta` int(11) DEFAULT NULL,
  `fecha_cbte` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cae` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `emision_tipo` varchar(4) COLLATE utf8_spanish_ci DEFAULT NULL,
  `err_msg` varchar(1000) COLLATE utf8_spanish_ci DEFAULT NULL,
  `err_code` varchar(6) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fch_venc_cae` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `motivos_obs` varchar(1000) COLLATE utf8_spanish_ci DEFAULT NULL,
  `reproceso` varchar(1) COLLATE utf8_spanish_ci DEFAULT NULL,
  `resultado` varchar(1) COLLATE utf8_spanish_ci DEFAULT NULL,
  `entrada` text COLLATE utf8_spanish_ci,
  `salida` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_fe_documento`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `fe_documento`
--

INSERT INTO `fe_documento` (`id_fe_documento`, `punto_vta`, `tipo_cbte`, `cbt_desde`, `cbt_hasta`, `fecha_cbte`, `cae`, `emision_tipo`, `err_msg`, `err_code`, `fch_venc_cae`, `motivos_obs`, `reproceso`, `resultado`, `entrada`, `salida`) VALUES
(1, 4000, 1, 1125, 1125, '20161026', '66433435737697', 'CAE', '', '', '20161105', '', '', 'A', '{"id":0,"punto_vta":4000,"tipo_cbte":1,"cbte_nro":1125,"tipo_doc":80,"nro_doc":"30000000007","fecha_cbte":"20161026","fecha_serv_desde":null,"fecha_serv_hasta":null,"fecha_venc_pago":null,"concepto":1,"nombre_cliente":"Joao Da Silva","domicilio_cliente":"Rua 76 km 34.5 Alagoas","pais_dst_cmp":16,"moneda_ctz":1,"moneda_id":"PES","obs_comerciales":"Observaciones Comerciales, texto libre","obs_generales":"Observaciones Generales, texto libre","forma_pago":"30 dias","incoterms":"FOB","id_impositivo":"PJ54482221-l","imp_neto":"100.00","imp_op_ex":"2.00","imp_tot_conc":"3.00","imp_iva":"21.00","imp_trib":"1.00","imp_total":"127.00","cae":"66433435737697","fecha_vto":"20161105","motivos_obs":"","err_code":"","descuento":0,"detalles":[{"qty":1,"umed":7,"codigo":"P0001","ds":"Descripcion del producto P0001","precio":100,"importe":121,"imp_iva":21,"iva_id":5,"u_mtx":123456,"cod_mtx":1234567890123,"despacho":"Nu00ba 123456","dato_a":null,"dato_b":null,"dato_c":null,"dato_d":null,"dato_e":null,"bonif":0}],"ivas":[{"base_imp":100,"importe":21,"iva_id":5}],"tributos":[{"alic":"1.00","base_imp":"100.00","desc":"Impuesto Municipal Matanza","importe":"1.00","tributo_id":99}],"permisos":[],"datos":[],"cbt_desde":1125,"cbt_hasta":1125,"err_msg":""}', '[{"cae":"66433435737697","cbt_desde":1125,"cbt_hasta":1125,"cbte_nro":1125,"cbtes_asoc":[],"concepto":1,"datos":[],"descuento":0,"detalles":[{"bonif":0,"cod_mtx":1234567890123,"codigo":"P0001","dato_a":null,"dato_b":null,"dato_c":null,"dato_d":null,"dato_e":null,"despacho":"Nu00ba 123456","ds":"Descripcion del producto P0001","imp_iva":21,"importe":121,"iva_id":5,"precio":100,"qty":1,"u_mtx":123456,"umed":7}],"domicilio_cliente":"Rua 76 km 34.5 Alagoas","emision_tipo":"CAE","err_code":"","err_msg":"","fch_venc_cae":"20161105","fecha_cbte":"20161026","fecha_serv_desde":null,"fecha_serv_hasta":null,"fecha_venc_pago":null,"fecha_vto":"20161105","forma_pago":"30 dias","id":0,"id_impositivo":"PJ54482221-l","imp_iva":"21.00","imp_neto":"100.00","imp_op_ex":"2.00","imp_tot_conc":"3.00","imp_total":"127.00","imp_trib":"1.00","incoterms":"FOB","ivas":[{"base_imp":100,"importe":21,"iva_id":5}],"moneda_ctz":1,"moneda_id":"PES","motivos_obs":"","nombre_cliente":"Joao Da Silva","nro_doc":"30000000007","obs_comerciales":"Observaciones Comerciales, texto libre","obs_generales":"Observaciones Generales, texto libre","opcionales":[],"pais_dst_cmp":16,"permisos":[],"punto_vta":4000,"reproceso":"","resultado":"A","tipo_cbte":1,"tipo_doc":80,"tributos":[{"alic":"1.00","base_imp":"100.00","desc":"Impuesto Municipal Matanza","importe":"1.00","tributo_id":99}]}]');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
