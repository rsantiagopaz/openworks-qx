-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 11-02-2017 a las 20:59:01
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `turismo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alerta`
--

CREATE TABLE IF NOT EXISTS `alerta` (
  `id_alerta` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(1024) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `tipo` enum('P','R','F','C') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'P Presupuesto, R Retorno, F Fijacion, C Cancelacion',
  `f_desde` datetime DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_alerta`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `alerta`
--

INSERT INTO `alerta` (`id_alerta`, `descrip`, `fecha`, `tipo`, `f_desde`, `id`, `activo`) VALUES
(1, 'Presupuesto asignado<br/>Fecha: 2016-11-16 21:44:08<br/>Usuario: Alejandro<br/>Presupuesto: <br/>Apellido: Paz<br/>Nombre: Ramon<br/>', '2016-11-16 21:44:08', 'P', '2016-11-17 21:44:08', 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `apellido` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `dni` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuit` varchar(13) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_nac` date DEFAULT NULL,
  `nro_pasaporte` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_venc` date DEFAULT NULL,
  `domicilio` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `cliente`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente_contacto`
--

CREATE TABLE IF NOT EXISTS `cliente_contacto` (
  `id_cliente` int(11) NOT NULL,
  `tipo` enum('C','E','T') COLLATE utf8_spanish_ci DEFAULT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `cliente_contacto`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `operacion`
--

CREATE TABLE IF NOT EXISTS `operacion` (
  `id_operacion` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `cant_mayores` tinyint(4) DEFAULT NULL,
  `cant_menores` tinyint(4) DEFAULT NULL,
  `pfdolar` decimal(8,2) DEFAULT NULL,
  `cotdolar` decimal(8,2) DEFAULT NULL,
  `json` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_operacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `operacion`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `operacion_cliente`
--

CREATE TABLE IF NOT EXISTS `operacion_cliente` (
  `id_operacion` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `operacion_cliente`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `operacion_producto_item`
--

CREATE TABLE IF NOT EXISTS `operacion_producto_item` (
  `id_operacion_producto_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_operacion` int(11) DEFAULT NULL,
  `producto` tinyint(1) DEFAULT NULL,
  `localizador` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `f_venc` datetime DEFAULT NULL,
  `precio` decimal(8,2) DEFAULT NULL,
  `cotiza` decimal(8,2) DEFAULT NULL,
  `comision` decimal(8,2) DEFAULT NULL,
  `percepcion` decimal(8,2) DEFAULT NULL,
  `cargo_gestion` decimal(8,2) DEFAULT NULL,
  `precio_neto` decimal(8,2) DEFAULT NULL,
  `politica_cancela` varchar(1000) COLLATE utf8_spanish_ci DEFAULT NULL,
  `json` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_operacion_producto_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `operacion_producto_item`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE IF NOT EXISTS `pago` (
  `id_pago` int(11) NOT NULL AUTO_INCREMENT,
  `id_operacion` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `importe` decimal(8,2) DEFAULT NULL,
  `tipo` enum('C','P') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'Cliente, Proveedor',
  `tipo_pago` enum('E','C','D','Q','T') COLLATE utf8_spanish_ci DEFAULT NULL,
  `json` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `pago`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago_item`
--

CREATE TABLE IF NOT EXISTS `pago_item` (
  `id_pago_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_pago` int(11) DEFAULT NULL,
  `id_operacion_producto_item` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_pago_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `pago_item`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paramet`
--

CREATE TABLE IF NOT EXISTS `paramet` (
  `id_paramet` int(11) NOT NULL AUTO_INCREMENT,
  `json` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_paramet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `paramet`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `presupuesto`
--

CREATE TABLE IF NOT EXISTS `presupuesto` (
  `id_proforma` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `pfdolar` decimal(8,2) DEFAULT NULL,
  `cotdolar` decimal(8,2) DEFAULT NULL,
  `archivo` varchar(128) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_operacion` int(11) DEFAULT NULL,
  UNIQUE KEY `id_proforma` (`id_proforma`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `presupuesto`
--

INSERT INTO `presupuesto` (`id_proforma`, `id_usuario`, `fecha`, `pfdolar`, `cotdolar`, `archivo`, `id_operacion`) VALUES
(1, 1, '2016-11-16 21:44:08', '10.00', '3.00', '', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `presupuesto_item`
--

CREATE TABLE IF NOT EXISTS `presupuesto_item` (
  `id_presupuesto_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_proforma` int(11) DEFAULT NULL,
  `producto` tinyint(1) DEFAULT NULL,
  `localizador` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `f_venc` datetime DEFAULT NULL,
  `precio` decimal(8,2) DEFAULT NULL,
  `cotiza` decimal(8,2) DEFAULT NULL,
  `comision` decimal(8,2) DEFAULT NULL,
  `percepcion` decimal(8,2) DEFAULT NULL,
  `cargo_gestion` decimal(8,2) DEFAULT NULL,
  `precio_neto` decimal(8,2) DEFAULT NULL,
  `politica_cancela` varchar(1000) COLLATE utf8_spanish_ci DEFAULT NULL,
  `json` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_presupuesto_item`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `presupuesto_item`
--

INSERT INTO `presupuesto_item` (`id_presupuesto_item`, `id_proforma`, `producto`, `localizador`, `descrip`, `f_venc`, `precio`, `cotiza`, `comision`, `percepcion`, `cargo_gestion`, `precio_neto`, `politica_cancela`, `json`) VALUES
(1, 1, 0, '1', '1', '2016-11-10 00:00:00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '', '{"ida_origen":"","ida_tramos":"","ida_destino":"","ida_duracion":"","vuelta":true,"vuelta_origen":"","vuelta_tramos":"","vuelta_destino":"","vuelta_duracion":""}'),
(2, 1, 2, '2', '2', '2016-11-12 00:00:00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2', '{"operador":"","empresa":"","f_recogida":null,"f_devolucion":null,"categoria":null,"descrip":""}'),
(3, 1, 3, '3', '3', '2016-11-13 00:00:00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '', '{}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proforma`
--

CREATE TABLE IF NOT EXISTS `proforma` (
  `id_proforma` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `tipo_entrevista` enum('P','T','E','F') COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellido` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tiempo_estimado` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_menores` tinyint(4) DEFAULT NULL,
  `cant_mayores` tinyint(4) DEFAULT NULL,
  `horario_contactar` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `presupuesto` tinyint(1) DEFAULT NULL,
  `json` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_proforma`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `proforma`
--

INSERT INTO `proforma` (`id_proforma`, `id_usuario`, `fecha`, `tipo_entrevista`, `apellido`, `nombre`, `tiempo_estimado`, `cant_menores`, `cant_mayores`, `horario_contactar`, `presupuesto`, `json`) VALUES
(1, 1, '2016-11-16 21:42:56', 'P', 'Paz', 'Ramon', '', 2, 2, '', 1, '{"producto":{"0":{"txt":""},"2":{"txt":""},"3":{"txt":""}}}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proforma_contactar`
--

CREATE TABLE IF NOT EXISTS `proforma_contactar` (
  `id_proforma` int(11) NOT NULL,
  `tipo` enum('C','E','T') COLLATE utf8_spanish_ci DEFAULT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `proforma_contactar`
--

INSERT INTO `proforma_contactar` (`id_proforma`, `tipo`, `descrip`) VALUES
(1, 'C', '45345');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proforma_historial`
--

CREATE TABLE IF NOT EXISTS `proforma_historial` (
  `id_proforma_historial` int(11) NOT NULL AUTO_INCREMENT,
  `id_proforma` int(11) DEFAULT NULL,
  `json` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_proforma_historial`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `proforma_historial`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proforma_token_destino`
--

CREATE TABLE IF NOT EXISTS `proforma_token_destino` (
  `id_proforma` int(11) NOT NULL,
  `id_token_destino` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `proforma_token_destino`
--

INSERT INTO `proforma_token_destino` (`id_proforma`, `id_token_destino`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proforma_token_motivo`
--

CREATE TABLE IF NOT EXISTS `proforma_token_motivo` (
  `id_proforma` int(11) NOT NULL,
  `id_token_motivo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `proforma_token_motivo`
--

INSERT INTO `proforma_token_motivo` (`id_proforma`, `id_token_motivo`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `token_destino`
--

CREATE TABLE IF NOT EXISTS `token_destino` (
  `id_token_destino` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_token_destino`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `token_destino`
--

INSERT INTO `token_destino` (`id_token_destino`, `descrip`) VALUES
(1, 'Nueva York');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `token_motivo`
--

CREATE TABLE IF NOT EXISTS `token_motivo` (
  `id_token_motivo` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_token_motivo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `token_motivo`
--

INSERT INTO `token_motivo` (`id_token_motivo`, `descrip`) VALUES
(1, 'Cumpleaños');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `password` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `descrip`, `password`) VALUES
(1, 'Alejandro', 'Alejandro'),
(2, 'Juan', 'Juan'),
(4, 'Ramon', 'Ramon'),
(5, 'Alentino', 'Alentino');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
