-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 11-02-2017 a las 20:59:43
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `gbio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE IF NOT EXISTS `departamento` (
  `id_departamento` int(11) NOT NULL AUTO_INCREMENT,
  `id_provincia` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_departamento`),
  KEY `fk_departamento_provincia1` (`id_provincia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `departamento`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE IF NOT EXISTS `empleado` (
  `id_empleado` int(11) NOT NULL AUTO_INCREMENT,
  `enroll_number` int(11) DEFAULT NULL COMMENT 'Nro de Legajo',
  `name` varchar(23) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'Nombre que figurara en el lector',
  `password` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT '?',
  `privilege` tinyint(4) DEFAULT '0' COMMENT '0=Usuario, 1=Administrador',
  `enabled` tinyint(1) DEFAULT NULL COMMENT '0=False, 1=True',
  `nro_doc` int(11) DEFAULT NULL,
  `apellido` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nacimiento` date DEFAULT NULL,
  `sexo` enum('F','M') COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado_civil` enum('S','C','D','V') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'S=Soltero, C=Casado, D=Divorciado, V=Viudo',
  `domicilio` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_ubicacion` int(11) DEFAULT NULL,
  `email` varchar(70) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `celular` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `ingreso` date DEFAULT NULL COMMENT 'Fecha de Ingreso a la Empresa',
  `condicion_laboral` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `contrato_desde` date DEFAULT NULL,
  `contrato_hasta` date DEFAULT NULL,
  `id_organigrama` int(11) DEFAULT NULL COMMENT 'Id de la hoja del arbol del organigrama de la empresa',
  `categoria` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `funcion` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `ficha_pin` enum('S','N') COLLATE utf8_spanish_ci DEFAULT 'N' COMMENT 'Si permite o no fichar con Pin',
  `foto` blob,
  `id_tolerancia` int(11) DEFAULT NULL,
  `id_lugar_trabajo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_empleado`),
  UNIQUE KEY `enroll_number_UNIQUE` (`enroll_number`),
  UNIQUE KEY `enroll_number` (`enroll_number`),
  KEY `fk_empleado_localidad1` (`id_ubicacion`),
  KEY `fk_empleado_organigrama1` (`id_organigrama`),
  KEY `fk_empleado_tolerancia1` (`id_tolerancia`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`id_empleado`, `enroll_number`, `name`, `password`, `privilege`, `enabled`, `nro_doc`, `apellido`, `nombre`, `nacimiento`, `sexo`, `estado_civil`, `domicilio`, `id_ubicacion`, `email`, `telefono`, `celular`, `ingreso`, `condicion_laboral`, `contrato_desde`, `contrato_hasta`, `id_organigrama`, `categoria`, `funcion`, `ficha_pin`, `foto`, `id_tolerancia`, `id_lugar_trabajo`) VALUES
(1, 123, 'RamonPaz', NULL, 0, 1, 21902181, 'Paz', 'Ramon Santiago', '2017-01-02', 'M', 'S', 'Andres Rojas 471', 2, '', '', '', '2017-02-28', NULL, NULL, NULL, NULL, NULL, NULL, 'N', NULL, 1, 1),
(2, 2, 'CarlosFilippa', '4444', 0, 1, 4444444, 'Filippa', 'Carlos', '1944-04-04', 'M', 'C', 'Misiones 148', 2, 'cgf@hotmail.com', '', '156974615', '2017-02-11', NULL, '2017-02-11', '2017-02-11', NULL, NULL, NULL, 'N', NULL, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_permiso`
--

CREATE TABLE IF NOT EXISTS `empleado_permiso` (
  `id_empleado_permiso` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado_turno` int(11) DEFAULT NULL,
  `id_permiso` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id_empleado_permiso`),
  KEY `fk_empleado_permiso_empleado_turno1` (`id_empleado_turno`),
  KEY `fk_empleado_permiso_permiso1` (`id_permiso`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=18 ;

--
-- Volcar la base de datos para la tabla `empleado_permiso`
--

INSERT INTO `empleado_permiso` (`id_empleado_permiso`, `id_empleado_turno`, `id_permiso`, `fecha`) VALUES
(11, 4, 1, '2017-02-16'),
(12, 4, 1, '2017-02-14'),
(16, 5, 1, '2017-03-22'),
(17, 3, 1, '2017-03-14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_reloj`
--

CREATE TABLE IF NOT EXISTS `empleado_reloj` (
  `id_empleado_reloj` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) DEFAULT NULL,
  `id_reloj` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_empleado_reloj`),
  UNIQUE KEY `id_empleado` (`id_empleado`,`id_reloj`),
  KEY `fk_empleado_reloj_empleado1` (`id_empleado`),
  KEY `fk_empleado_reloj_reloj1` (`id_reloj`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `empleado_reloj`
--

INSERT INTO `empleado_reloj` (`id_empleado_reloj`, `id_empleado`, `id_reloj`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_turno`
--

CREATE TABLE IF NOT EXISTS `empleado_turno` (
  `id_empleado_turno` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) DEFAULT NULL,
  `id_turno` int(11) DEFAULT NULL,
  `desde` date DEFAULT NULL COMMENT 'Desde cuando empieza a regir',
  `hasta` date DEFAULT NULL COMMENT 'Hasta cuando rige (puede ser null lo cual indica sin fecha de corte)',
  PRIMARY KEY (`id_empleado_turno`),
  KEY `fk_empleado_turno_empleado` (`id_empleado`),
  KEY `fk_empleado_turno_turno1` (`id_turno`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `empleado_turno`
--

INSERT INTO `empleado_turno` (`id_empleado_turno`, `id_empleado`, `id_turno`, `desde`, `hasta`) VALUES
(3, 1, 1, '2017-01-01', NULL),
(4, 1, 1, '2017-01-01', '2017-01-31'),
(5, 2, 1, '2017-02-01', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fichaje`
--

CREATE TABLE IF NOT EXISTS `fichaje` (
  `id_fichaje` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado_reloj` int(11) DEFAULT NULL,
  `verify_mode` tinyint(4) DEFAULT NULL COMMENT 'Forma que ficho (Huella, Pin, Tarjeta?)',
  `inout_mode` tinyint(4) DEFAULT NULL COMMENT '0=Salida?, 1=Entrada?',
  `fecha_hora` datetime DEFAULT NULL,
  `workcode` tinyint(4) DEFAULT NULL COMMENT '?',
  `tipo` enum('R','M','V') COLLATE utf8_spanish_ci DEFAULT 'R' COMMENT 'R=Real (reloj), M=Modificado, V=Virtual (Agregado por el usuario)',
  `id_usuario` int(11) DEFAULT NULL,
  `ult_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_fichaje`),
  KEY `fk_fichaje_empleado_reloj1` (`id_empleado_reloj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `fichaje`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `huella`
--

CREATE TABLE IF NOT EXISTS `huella` (
  `id_huella` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) DEFAULT NULL,
  `finger_index` tinyint(4) DEFAULT NULL COMMENT 'Nro de dedo',
  `flag` tinyint(4) DEFAULT NULL,
  `tmp_length` int(11) DEFAULT NULL COMMENT 'Length del campo Data',
  `tmp_data` text COLLATE utf8_spanish_ci COMMENT 'Huella',
  PRIMARY KEY (`id_huella`),
  KEY `fk_huella_empleado1` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `huella`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `localidad`
--

CREATE TABLE IF NOT EXISTS `localidad` (
  `id_localidad` int(11) NOT NULL AUTO_INCREMENT,
  `id_departamento` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cp` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_localidad`),
  KEY `fk_localidad_departamento1` (`id_departamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `localidad`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugar_trabajo`
--

CREATE TABLE IF NOT EXISTS `lugar_trabajo` (
  `id_lugar_trabajo` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id_lugar_trabajo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `lugar_trabajo`
--

INSERT INTO `lugar_trabajo` (`id_lugar_trabajo`, `descrip`) VALUES
(1, 'Defensoria del Pueblo'),
(2, 'Escribania de Gobierno');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `organigrama`
--

CREATE TABLE IF NOT EXISTS `organigrama` (
  `id_organigrama` int(11) NOT NULL AUTO_INCREMENT,
  `id_padre` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_hijos` tinyint(4) DEFAULT NULL,
  `cant_empleados` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_organigrama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `organigrama`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paramet`
--

CREATE TABLE IF NOT EXISTS `paramet` (
  `id_paramet` int(11) NOT NULL,
  `json` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id_paramet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `paramet`
--

INSERT INTO `paramet` (`id_paramet`, `json`) VALUES
(1, '{"notificacion_permisos":{"hora":"21:22","emails":["rsantiagopaz@hotmail.com","ll@ll.com","rr@rr.com","prueba@prueba.com","per@per.com","pp@pp.com","k@k.com"]}}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permiso`
--

CREATE TABLE IF NOT EXISTS `permiso` (
  `id_permiso` int(11) NOT NULL AUTO_INCREMENT,
  `id_lugar_trabajo` int(11) DEFAULT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `entrada` tinyint(1) DEFAULT NULL COMMENT 'Permiso en la Entrada',
  `salida` tinyint(1) DEFAULT NULL COMMENT 'Permiso en la Salida',
  `pagas` tinyint(1) DEFAULT NULL COMMENT 'Si dicho permiso afecta en el sueldo',
  `activo` tinyint(1) DEFAULT NULL COMMENT 'S=Habilitado, N=Deshabilitado',
  `hora_asignacion_limite` time DEFAULT NULL,
  `primer_aviso` tinyint(4) DEFAULT NULL,
  `segundo_aviso` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_permiso`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `permiso`
--

INSERT INTO `permiso` (`id_permiso`, `id_lugar_trabajo`, `descrip`, `entrada`, `salida`, `pagas`, `activo`, `hora_asignacion_limite`, `primer_aviso`, `segundo_aviso`) VALUES
(1, 1, 'primer permiso', 1, 0, 0, 1, '09:00:00', 4, 7),
(2, 1, 'segund 2o permiso', 1, 1, 1, 1, '22:00:00', 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincia`
--

CREATE TABLE IF NOT EXISTS `provincia` (
  `id_provincia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_provincia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `provincia`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reloj`
--

CREATE TABLE IF NOT EXISTS `reloj` (
  `id_reloj` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `host` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'ip o host donde se encuentra el reloj',
  `ultima_sincro` datetime DEFAULT NULL COMMENT 'Fecha y Hora de ultima sincronizacion',
  PRIMARY KEY (`id_reloj`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `reloj`
--

INSERT INTO `reloj` (`id_reloj`, `descrip`, `host`, `ultima_sincro`) VALUES
(1, 'unico', '10.0.0.20', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tolerancia`
--

CREATE TABLE IF NOT EXISTS `tolerancia` (
  `id_tolerancia` int(11) NOT NULL AUTO_INCREMENT,
  `id_lugar_trabajo` int(11) DEFAULT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `entrada_extras` tinyint(1) DEFAULT NULL COMMENT 'Son horas extras antes de la hora de entrada',
  `e_fichada` tinyint(4) DEFAULT '0' COMMENT 'Min. desde entrada para fichada normal',
  `e_tolerable` tinyint(4) DEFAULT '0' COMMENT 'Min. desde entrada para tardanza tolerable',
  `e_tardanza` tinyint(4) DEFAULT '0' COMMENT 'Min. desde entrada para tardanza',
  `salida_extras` tinyint(1) DEFAULT NULL COMMENT 'Son horas extras despues de hora de salida',
  `s_fichada` tinyint(4) DEFAULT '0' COMMENT 'Min. antes salida para fichada normal',
  `s_tolerable` tinyint(4) DEFAULT '0' COMMENT 'Min. antes salida para salida tolerable',
  `s_abandono` tinyint(4) DEFAULT '0' COMMENT 'Min. antes salida para salida con abandono de trabajo',
  `desde` date DEFAULT NULL COMMENT 'Desde cuando rige',
  `hasta` date DEFAULT NULL COMMENT 'Puede ser NULL porque no se define hasta cuando se tiene en cuenta',
  PRIMARY KEY (`id_tolerancia`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `tolerancia`
--

INSERT INTO `tolerancia` (`id_tolerancia`, `id_lugar_trabajo`, `descrip`, `entrada_extras`, `e_fichada`, `e_tolerable`, `e_tardanza`, `salida_extras`, `s_fichada`, `s_tolerable`, `s_abandono`, `desde`, `hasta`) VALUES
(1, 1, 'primer tolerancia', 0, 0, 0, 0, 0, 0, 0, 0, NULL, '2017-02-10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turno`
--

CREATE TABLE IF NOT EXISTS `turno` (
  `id_turno` int(11) NOT NULL AUTO_INCREMENT,
  `id_lugar_trabajo` int(11) DEFAULT NULL,
  `tipo` enum('F','X','V') COLLATE utf8_spanish_ci DEFAULT 'F' COMMENT 'F=Fijo, X=Flexible, V=Variable',
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `entrada` time DEFAULT NULL COMMENT 'Fijos y Variables',
  `salida` time DEFAULT NULL COMMENT 'Fijos y Variables',
  `lu` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `ma` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `mi` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `ju` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `vi` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `sa` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `do` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `cant_horas` tinyint(4) DEFAULT NULL COMMENT 'Cantidad de Horas Diarias (flexibles)',
  `activo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_turno`),
  UNIQUE KEY `nombre_UNIQUE` (`descrip`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `turno`
--

INSERT INTO `turno` (`id_turno`, `id_lugar_trabajo`, `tipo`, `descrip`, `entrada`, `salida`, `lu`, `ma`, `mi`, `ju`, `vi`, `sa`, `do`, `cant_horas`, `activo`) VALUES
(1, 1, 'F', 'primer turno', '08:00:00', '12:00:00', 1, 1, 1, 1, 1, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE IF NOT EXISTS `ubicacion` (
  `id_ubicacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_padre` int(11) DEFAULT NULL,
  `descrip` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`id_ubicacion`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=12 ;

--
-- Volcar la base de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`id_ubicacion`, `id_padre`, `descrip`) VALUES
(1, 0, ''),
(2, 1, 'Argentina'),
(3, 2, 'Santiago del Estero'),
(4, 3, 'Capital'),
(5, 4, 'Santiago del Estero'),
(6, 1, 'Brasil'),
(7, 3, 'Banda'),
(8, 7, 'La Banda'),
(9, 2, 'Cordoba'),
(10, 9, 'Capital'),
(11, 10, 'Cordoba');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(35) COLLATE utf8_spanish_ci DEFAULT NULL,
  `password` varchar(35) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo` enum('A','U') COLLATE utf8_spanish_ci DEFAULT 'U' COMMENT 'A=Admin, U=Usuario',
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=18 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `usuario`, `password`, `tipo`) VALUES
(1, 'root', '63a9f0ea7bb98050796b649e85481845', 'A'),
(2, 'usuario', 'f8032d5cae3de20fcec887f395ec9a6a', 'U'),
(3, 'rodrigodelarua', 'b3bc43a3fc65c100c11ad4d7757151e4', 'A'),
(4, 'gustavodelasilva', 'd41d8cd98f00b204e9800998ecf8427e', 'U'),
(5, 'roxanacasares', 'a8f10f667f071064279764353dd518ff', 'U'),
(6, 'enriqueheredia', '8b9127934238e9a03691225c734a0a71', 'U'),
(7, 'diazachaval', 'ad46198538fd10685c6b1e5fead3eff6', 'A'),
(8, 'guidoespeche', '00993e01a0917beda6ff521af894feca', 'A'),
(9, 'diegodiaz', '31b70b3e803fb9bc82590f45e7a5f66d', 'U'),
(10, 'martaorieta', 'DADO DE BAJA', 'U'),
(11, 'angelescastaño', 'DADO DE BAJA', 'U'),
(12, 'brendavillar', 'DADO DE BAJA', 'U'),
(13, 'rosapresidente', 'DADO DE BAJA', 'U'),
(14, 'agostinalorenzo', 'DADO DE BAJA', 'U'),
(15, 'maguidiaz', 'DADO DE BAJA', 'U'),
(16, 'dellaringacecilia', '1d7c0fb835ae2ef51257c1bf4dd4371e', 'U'),
(17, 'rsantiagopaz', '1360e22ff6adbc680380c17a0421faeb', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_lugar_trabajo`
--

CREATE TABLE IF NOT EXISTS `usuario_lugar_trabajo` (
  `id_usuario` int(11) DEFAULT NULL,
  `id_lugar_trabajo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcar la base de datos para la tabla `usuario_lugar_trabajo`
--

INSERT INTO `usuario_lugar_trabajo` (`id_usuario`, `id_lugar_trabajo`) VALUES
(5, 1),
(1, 1),
(1, 2),
(6, 2),
(2, 1),
(7, 1),
(8, 1),
(3, 1),
(9, 1),
(11, 1),
(12, 1),
(14, 1),
(15, 1),
(16, 1),
(4, 1),
(10, 1),
(13, 1),
(17, 1),
(17, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
