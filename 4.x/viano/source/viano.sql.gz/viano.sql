-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 11-02-2017 a las 21:00:58
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `viano`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrega`
--

CREATE TABLE IF NOT EXISTS `entrega` (
  `id_entrega` int(11) NOT NULL AUTO_INCREMENT,
  `id_entrega_lugar` int(11) DEFAULT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id_entrega`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `entrega`
--

INSERT INTO `entrega` (`id_entrega`, `id_entrega_lugar`, `descrip`, `fecha`) VALUES
(1, 1, 'detalle 1', '2014-09-11 21:21:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrega_item`
--

CREATE TABLE IF NOT EXISTS `entrega_item` (
  `id_entrega_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_entrega` int(11) DEFAULT NULL,
  `id_stock` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_entrega_item`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `entrega_item`
--

INSERT INTO `entrega_item` (`id_entrega_item`, `id_entrega`, `id_stock`, `id_producto`, `cantidad`) VALUES
(1, 1, 4, 3, 1),
(2, 1, 5, 3, 2),
(3, 1, 3, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrega_lugar`
--

CREATE TABLE IF NOT EXISTS `entrega_lugar` (
  `id_entrega_lugar` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_entrega_lugar`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=18446744073709551615 ;

--
-- Volcar la base de datos para la tabla `entrega_lugar`
--

INSERT INTO `entrega_lugar` (`id_entrega_lugar`, `descrip`) VALUES
(1, 'Laboratorio');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingreso`
--

CREATE TABLE IF NOT EXISTS `ingreso` (
  `id_ingreso` int(11) NOT NULL AUTO_INCREMENT,
  `id_ingreso_lugar` int(11) DEFAULT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id_ingreso`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `ingreso`
--

INSERT INTO `ingreso` (`id_ingreso`, `id_ingreso_lugar`, `descrip`, `fecha`) VALUES
(1, 1, 'preva', '2014-09-11 20:51:49'),
(2, 2, 'segunda preva', '2014-09-11 21:01:09');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingreso_item`
--

CREATE TABLE IF NOT EXISTS `ingreso_item` (
  `id_ingreso_item` int(11) NOT NULL AUTO_INCREMENT,
  `id_ingreso` int(11) DEFAULT NULL,
  `id_stock` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `lote` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `f_vencimiento` date DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_ingreso_item`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `ingreso_item`
--

INSERT INTO `ingreso_item` (`id_ingreso_item`, `id_ingreso`, `id_stock`, `id_producto`, `lote`, `f_vencimiento`, `cantidad`) VALUES
(1, 1, 1, 2, '123', '2014-09-09', 10),
(2, 1, 2, 2, '345', '2014-09-17', 100),
(3, 1, 3, 1, 'xcvxcv', '2014-09-16', 20),
(4, 2, 4, 3, 'dvbcvb', '2014-09-01', 100),
(5, 2, 5, 3, 'fcfg', '2014-09-18', 200);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingreso_lugar`
--

CREATE TABLE IF NOT EXISTS `ingreso_lugar` (
  `id_ingreso_lugar` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_ingreso_lugar`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=18446744073709551615 ;

--
-- Volcar la base de datos para la tabla `ingreso_lugar`
--

INSERT INTO `ingreso_lugar` (`id_ingreso_lugar`, `descrip`) VALUES
(1, 'Compra'),
(2, 'Sec. Tec. Bioq.'),
(3, 'Otro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE IF NOT EXISTS `producto` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `pto_reposicion` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_producto`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `producto`
--

INSERT INTO `producto` (`id_producto`, `descrip`, `pto_reposicion`) VALUES
(1, 'primer producto', 0),
(2, 'segundo producto', 0),
(3, 'tercer producto', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `id_stock` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto` int(11) DEFAULT NULL,
  `lote` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `f_vencimiento` date DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_stock`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `stock`
--

INSERT INTO `stock` (`id_stock`, `id_producto`, `lote`, `f_vencimiento`, `stock`) VALUES
(1, 2, '123', '2014-09-09', 10),
(2, 2, '345', '2014-09-17', 100),
(3, 1, 'xcvxcv', '2014-09-16', 18),
(4, 3, 'dvbcvb', '2014-09-01', 99),
(5, 3, 'fcfg', '2014-09-18', 198);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
